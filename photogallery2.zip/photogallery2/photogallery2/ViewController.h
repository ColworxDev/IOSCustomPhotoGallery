//
//  ViewController.h
//  photogallery2
//
//  Created by shujat ali on 7/25/15.
//  Copyright (c) 2015 shujat ali. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PhotoPageViewController.h"
@interface ViewController : UIViewController<PhotoPageViewControllerDelegate>

- (IBAction)btnpressed:(UIButton *)sender;

@end

