//
//  PhotoItem2.m
//  photogallery2
//
//  Created by shujat ali on 7/26/15.
//  Copyright (c) 2015 shujat ali. All rights reserved.
//

#import "PhotoItem.h"

@implementation PhotoItem

@end
