//
//  PhotoItem2.h
//  photogallery2
//
//  Created by shujat ali on 7/26/15.
//  Copyright (c) 2015 shujat ali. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PhotoItem : NSObject

@property (weak, nonatomic)  NSString *urlString;
@property (weak, nonatomic)  NSString *titletext;
@property (weak, nonatomic)  NSString *descriptiontext;
@property (weak, nonatomic)  NSString *placeholderimagename;


@end
